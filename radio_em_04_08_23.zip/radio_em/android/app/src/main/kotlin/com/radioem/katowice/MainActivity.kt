package com.radioem.katowice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
