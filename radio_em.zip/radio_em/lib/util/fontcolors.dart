import 'package:flutter/material.dart';

var redFontColor = Color(0xffE4012F);
var whiteFontColor = Color(0xffFFFFFF);
var topHederTwoColor = Color(0xff242424);
var fontColor1 = Color(0xff828282);
var fontcolor2 = Color(0xff333333);
