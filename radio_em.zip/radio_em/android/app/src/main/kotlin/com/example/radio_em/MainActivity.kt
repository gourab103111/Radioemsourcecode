package com.example.radio_em

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
